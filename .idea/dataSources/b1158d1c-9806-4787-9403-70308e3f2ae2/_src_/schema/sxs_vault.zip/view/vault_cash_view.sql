CREATE VIEW `vault_cash_view` AS
  SELECT
    `a`.`id`                AS `id`,
    `a`.`user_id`           AS `user_id`,
    `a`.`total_money`       AS `total_money`,
    `a`.`logtime`           AS `logtime`,
    `a`.`before_cash_money` AS `before_cash_money`,
    `a`.`out_money`         AS `out_money`,
    `a`.`total_cash_money`  AS `total_cash_money`,
    `a`.`interest_money`    AS `interest_money`,
    `a`.`redpack_money`     AS `redpack_money`,
    `a`.`rebate_money`      AS `rebate_money`,
    `a`.`warning_money`     AS `warning_money`,
    `a`.`last_money`        AS `last_money`,
    `a`.`state`             AS `state`,
    `a`.`fee`               AS `fee`,
    `a`.`verify_manger`     AS `verify_manger`,
    `a`.`verify_time`       AS `verify_time`,
    `b`.`real_name`         AS `username`,
    `b`.`moblie`            AS `phone`
  FROM (`sxs_vault`.`vault_user_cash_log` `a`
    JOIN `sxs_vault`.`vault_user` `b`)
  WHERE (`a`.`user_id` = `b`.`id`)